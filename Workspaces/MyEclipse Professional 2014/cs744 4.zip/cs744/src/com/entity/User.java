package com.entity;

public class User {

	private String uid;
	private String firstName;
	private String lastName;
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	private String password;
	private Integer qID1;
	private Integer qID2;
	private Integer qID3;
	private String ans1;
	
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Integer getqID1() {
		return qID1;
	}
	public void setqID1(Integer qID1) {
		this.qID1 = qID1;
	}
	public Integer getqID2() {
		return qID2;
	}
	public void setqID2(Integer qID2) {
		this.qID2 = qID2;
	}
	public Integer getqID3() {
		return qID3;
	}
	public void setqID3(Integer qID3) {
		this.qID3 = qID3;
	}
	public String getAns1() {
		return ans1;
	}
	public void setAns1(String ans1) {
		this.ans1 = ans1;
	}
	public String getAns2() {
		return ans2;
	}
	public void setAns2(String ans2) {
		this.ans2 = ans2;
	}
	public String getAns3() {
		return ans3;
	}
	public void setAns3(String ans3) {
		this.ans3 = ans3;
	}
	private String ans2;
	private String ans3;
	
	

}
